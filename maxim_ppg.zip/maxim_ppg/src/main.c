#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>
#include <zephyr/drivers/sensor/max30101.h>
#include "hr_calc.h"

#define PPG_ADDR        0x57

LOG_MODULE_REGISTER(PPG, LOG_LEVEL_INF);

const struct device *dev = DEVICE_DT_GET(DT_NODELABEL(max30101));
const struct device *i2c_bus = DEVICE_DT_GET(DT_NODELABEL(i2c22));

// define HR context struct
hr_context_t hr_ctx;

/* --- I2C SCANNER FUNCTION --- */
void scan_i2c_bus(const struct device *dev)
{
    LOG_INF("Starting I2C Scan on %s...", dev->name);
    // uint8_t error = 0u;
    bool found = false;

    for (uint8_t i = 1; i <= 127; i++) {
        struct i2c_msg msgs[1];
        uint8_t dst;

        /* Send a zero-length write to probe the address */
        msgs[0].buf = &dst;
        msgs[0].len = 0U;
        msgs[0].flags = I2C_MSG_WRITE | I2C_MSG_STOP;

        if (i2c_transfer(dev, &msgs[0], 1, i) == 0) {
            LOG_INF("--> Found device at 0x%02x", i);
            found = true;
        }
    }

    if (!found) {
        LOG_ERR("No devices found on I2C bus! Check SDA/SCL wiring.");
    } else {
        LOG_INF("I2C Scan Complete.");
    }
}

// // temp test
// int main(void)
// {
//     k_msleep(1000); /* Power stabilization */

//     if (!device_is_ready(dev)) {
//         LOG_ERR("MAX30102 Driver not ready.");
//         return 0;
//     }
//     LOG_INF("MAX30102 Driver Initialized. Testing Temperature...");

//     while (1) {
//         /* 1. Fetch Data */
//         int ret = sensor_sample_fetch(dev);
//         if (ret < 0) {
//             LOG_ERR("Fetch failed (Error: %d)", ret);
//         } else {
//             /* 2. Get Temperature (Works independently of LEDs) */
//             struct sensor_value temp_val;
            
//             /* SENSOR_CHAN_DIE_TEMP is the standard channel for chip temperature */
//             if (sensor_channel_get(dev, SENSOR_CHAN_DIE_TEMP, &temp_val) == 0) {
//                 LOG_INF("🌡️ Chip Temp: %.2f C", sensor_value_to_double(&temp_val));
//             } else {
//                 LOG_ERR("Could not read Temp channel.");
//             }

//             /* 3. Try to get Red LED value (Might be 0 if defaults are off) */
//             struct sensor_value red_val;
//             sensor_channel_get(dev, SENSOR_CHAN_RED, &red_val);
//             LOG_INF("🔴 Red Raw: %d", red_val.val1);
//         }

//         k_msleep(1000);
//     }
//     return 0;
// }

int main(void)
{
        // power up delay for device
        k_msleep(1000);

        // init hr_context var
        hr_init(&hr_ctx);

        // check if devices are ready
        if (!device_is_ready(i2c_bus)){
                LOG_ERR("I2C bus not ready");
                return 0;
        } else {
                // scan for devices on I2C bus
                scan_i2c_bus(i2c_bus);
        }
        
        /* 3. Soft Reset & ID Check */
        LOG_INF("Attempting Soft Reset...");
        uint8_t reset_cmd[2] = {MAX30101_REG_MODE_CFG, 0x40}; /* Bit 6 = Reset */
        i2c_write(i2c_bus, reset_cmd, 2, PPG_ADDR);
        k_msleep(100); /* Wait for reset */

        /* FIFO Config: Enable Rollover (0x10) */
        reset_cmd[0] = MAX30101_REG_FIFO_CFG; reset_cmd[1] = 0x10; 
        i2c_write(i2c_bus, reset_cmd, 2, PPG_ADDR);

        // verify ppg sensor ID
        uint8_t part_id = 0;
        uint8_t reg_addr = MAX30101_REG_PART_ID;
    
        // try to read sensor ID reg
        int ret = i2c_write_read(i2c_bus, PPG_ADDR, &reg_addr, 1, &part_id, 1);
    
        /* Proceed if I2C transaction succeeded (ret==0), even if ID is 0xFF */
        if (ret == 0) {
                LOG_INF("Sensor Found on Bus! Read ID: 0x%02x (Proceeding anyway...)", part_id);
        
                /* --- CONFIGURE SENSOR MANUALLY --- */
                uint8_t config[2];

                /* Reset FIFO Pointers */
                config[0] = MAX30101_REG_FIFO_WR; config[1] = 0x00;
                i2c_write(i2c_bus, config, 2, PPG_ADDR);
                config[0] = MAX30101_REG_FIFO_RD; config[1] = 0x00;
                i2c_write(i2c_bus, config, 2, PPG_ADDR);

                /* Mode: SpO2 (Red + IR) */
                config[0] = MAX30101_REG_MODE_CFG; config[1] = 0x03; 
                i2c_write(i2c_bus, config, 2, PPG_ADDR);

                // /* Config: 400Hz Sample Rate (0x01 << 2), 411us Pulse Width (0x03), Range 4096nA (0x01 << 5) */
                // /* Hex: 0x2F */
                // config[0] = MAX30101_REG_SPO2_CFG; config[1] = 0x2F;
                // i2c_write(i2c_bus, config, 2, PPG_ADDR);

                /* SpO2 Config: SAFE SETTINGS
                * Range: 4096nA (01)
                * Rate:  100 Hz  (010) <-- Slowed down from 400Hz
                * Pulse: 215 us  (10)  <-- Shortened from 411us
                * Binary: 00 01 010 10 -> Hex: 0x2A
                */
                config[0] = MAX30101_REG_SPO2_CFG; config[1] = 0x2A;
                i2c_write(i2c_bus, config, 2, PPG_ADDR);

                /* LED Currents (~7mA) */
                config[0] = MAX30101_REG_LED1_PA; config[1] = 0x24; 
                i2c_write(i2c_bus, config, 2, PPG_ADDR);
                config[0] = MAX30101_REG_LED2_PA; config[1] = 0x24; 
                i2c_write(i2c_bus, config, 2, PPG_ADDR);

                LOG_INF("MAX30102 Configured. Look for RED Light.");  
        } else {
                LOG_ERR("I2C Communication Failed (NACK). Check Wires.");
                return 0;
        }

        /* 3. VERIFY CONFIGURATION (Read Back) */
        reg_addr = MAX30101_REG_MODE_CFG;
        uint8_t read_val = 0;
        i2c_write_read(i2c_bus, PPG_ADDR, &reg_addr, 1, &read_val, 1);
        
        LOG_INF("VERIFY: Mode Register is 0x%02x (Expected 0x03)", read_val);
        
        if (read_val != 0x03) {
                LOG_ERR("Setup Failed! Sensor is not accepting config.");
        }

        // normal ppg configuration
        // if (ret == 0 && part_id == 0x15) {
        //         LOG_INF("PPG sensor found (ID: 0x15)");
        // } else {
        //         LOG_ERR("MAX30102 Not Found. Read ID: 0x%02x (Expected 0x15)", part_id);
        // }

        // if (device_is_ready(dev)){
        //         LOG_INF("Configuring PPG device...");
        //         uint8_t config[2];

        //         // reset FIFO pointers
        //         config[0] = MAX30101_REG_FIFO_WR;
        //         config[1] = 0x00;
        //         i2c_write(i2c_bus, config, 2, PPG_ADDR);
        //         config[0] = MAX30101_REG_FIFO_RD;
        //         config[1] = 0x00;
        //         i2c_write(i2c_bus, config, 2, PPG_ADDR);

        //         // set to SpO2 mode (Red + IR)
        //         config[0] = MAX30101_REG_MODE_CFG;
        //         config[1] = 0x03;
        //         i2c_write(i2c_bus, config, 2, PPG_ADDR);

        //         // config 400Hz sampling rate w 411us pulse width
        //         config[0] = MAX30101_REG_SPO2_CFG;
        //         config[1] = 0x2F; // ADC Range 4096 (01) | 400Hz (011) | 411 pulse (11)
        //         i2c_write(i2c_bus, config, 2, PPG_ADDR);

        //         // set LED currents (~7mA)
        //         config[0] = MAX30101_REG_LED1_PA;
        //         config[1] = 0x24;
        //         i2c_write(i2c_bus, config, 2, PPG_ADDR);
        //         config[0] = MAX30101_REG_LED2_PA;
        //         config[1] = 0x24;
        //         i2c_write(i2c_bus, config, 2, PPG_ADDR);

        //         LOG_INF("PPG sensor configured for 400Hz");
        // } else {
        //         LOG_ERR("PPG sensor not ready");
        //         return 0;
        // }

        int loop_count = 0;

        // ppg measurement loop
        while (1) {
                // check if new data is available
                uint8_t ptrs[2] = {0};
                uint8_t reg_addr_wr = MAX30101_REG_FIFO_WR;
                uint8_t reg_addr_rd = MAX30101_REG_FIFO_RD;

                // i2c_write_read(i2c_bus, PPG_ADDR, &reg_addr_wr, 1, &ptrs[0], 1); // Get Write Ptr
                // i2c_write_read(i2c_bus, PPG_ADDR, &reg_addr_rd, 1, &ptrs[1], 1); // Get Read Ptr

                bool debug_print = (loop_count++ % 10 == 0); /* Print every 1s (since sleep is 100ms now) */

                i2c_write_read(i2c_bus, PPG_ADDR, &reg_addr_wr, 1, &ptrs[0], 1); 
                i2c_write_read(i2c_bus, PPG_ADDR, &reg_addr_rd, 1, &ptrs[1], 1); 

                if (debug_print) {
                        LOG_INF("STATUS: WrPtr=%d, RdPtr=%d", ptrs[0], ptrs[1]);
                }

                // manual read loop
                int num_samples = ptrs[0] - ptrs[1];
                if (num_samples < 0) num_samples += 32;

                if (num_samples > 0) {
                        uint8_t fifo_data[6];
                        uint8_t reg_data = MAX30101_REG_FIFO_DATA;

                        /* Read 1 Sample */
                        if (i2c_write_read(i2c_bus, PPG_ADDR, &reg_data, 1, fifo_data, 6) == 0) {
                                uint32_t ir_val = ((uint32_t)fifo_data[3] << 16) | 
                                                ((uint32_t)fifo_data[4] << 8)  | 
                                                (uint32_t)fifo_data[5];
                                ir_val &= 0x3FFFF;

                                hr_process(&hr_ctx, ir_val);

                                if (hr_ctx.beat_detected) {
                                LOG_INF("❤️ BPM: %d | HRV: %.2f ms", 
                                        hr_ctx.current_bpm, (double)hr_ctx.current_rmssd);
                                }
                        }
                }

                // standard read loop
                // // if write != read, new data is available
                // if (ptrs[0] != ptrs[1]) {
                //         uint8_t fifo_data[6];
                //         uint8_t reg_data = MAX30101_REG_FIFO_DATA;

                //         // read 1 sample (6 bytes)
                //         if (i2c_write_read(i2c_bus, PPG_ADDR, &reg_data, 1, fifo_data, 6) == 0) {
                
                //                 // combine IR bytes
                //                 uint32_t ir_val = ((uint32_t)fifo_data[3] << 16) | 
                //                                 ((uint32_t)fifo_data[4] << 8)  | 
                //                                 (uint32_t)fifo_data[5];
                //                 ir_val &= 0x3FFFF; // mask to 18 bits

                //                 // run HR calc algo
                //                 hr_process(&hr_ctx, ir_val);

                //                 // print out HR values
                //                 if (hr_ctx.beat_detected) {
                //                         LOG_INF("BPM: %d | HRV: %.2f ms", hr_ctx.current_bpm, (double)hr_ctx.current_rmssd);
                //                 }
                //         }
                // }
                // sleep for 2.5ms (400 Hz SR)
                k_usleep(2500);
        }
        return 0;
}
