#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>
#include <zephyr/drivers/sensor/max30101.h>
#include "hr_calc.h"

#define PPG_ADDR        0x57

LOG_MODULE_REGISTER(PPG, LOG_LEVEL_INF);

const struct device *dev = DEVICE_DT_GET(DT_NODELABEL(max30101));
const struct device *i2c_bus = DEVICE_DT_GET(DT_NODELABEL(i2c22));

// define HR context struct
hr_context_t hr_ctx;

// i2c scanner function
void scan_i2c_bus(const struct device *dev)
{
    LOG_INF("Starting I2C Scan on %s...", dev->name);
    // uint8_t error = 0u;
    bool found = false;

    for (uint8_t i = 1; i <= 127; i++) {
        struct i2c_msg msgs[1];
        uint8_t dst;

        /* Send a zero-length write to probe the address */
        msgs[0].buf = &dst;
        msgs[0].len = 0U;
        msgs[0].flags = I2C_MSG_WRITE | I2C_MSG_STOP;

        if (i2c_transfer(dev, &msgs[0], 1, i) == 0) {
            LOG_INF("--> Found device at 0x%02x", i);
            found = true;
        }
    }

    if (!found) {
        LOG_ERR("No devices found on I2C bus! Check SDA/SCL wiring.");
    } else {
        LOG_INF("I2C Scan Complete.");
    }
}

// configure PPG sensor helper
void configure_sensor(void) {
        uint8_t config[2];
        LOG_INF("Configuring MAX30102...");
    
        // reset ppg sensor
        config[0] = MAX30101_REG_MODE_CFG; config[1] = 0x40;
        i2c_write(i2c_bus, config, 2, PPG_ADDR);
        k_msleep(100);
    
        // configure fifo and enable rollover
        config[0] = MAX30101_REG_FIFO_CFG; config[1] = 0x10;
        i2c_write(i2c_bus, config, 2, PPG_ADDR);
    
        // configure spO2 mode (SpO2 = Red + IR) */
        config[0] = MAX30101_REG_MODE_CFG; config[1] = 0x03;
        i2c_write(i2c_bus, config, 2, PPG_ADDR);
    
        /* Sp02 configuration
         * Range: 4096nA (01)
         * Rate:  400 Hz  (011) <-- High speed for HRV
         * Pulse: 411 us  (11)
         * Binary: 0010 1111 -> 0x2F
         */
        config[0] = MAX30101_REG_SPO2_CFG; config[1] = 0x2F;
        i2c_write(i2c_bus, config, 2, PPG_ADDR);
    
        // configue LED current at ~7mA (0x24)
        config[0] = MAX30101_REG_LED1_PA; config[1] = 0x24; /* RED */
        i2c_write(i2c_bus, config, 2, PPG_ADDR);
        config[0] = MAX30101_REG_LED2_PA; config[1] = 0x24; /* IR */
        i2c_write(i2c_bus, config, 2, PPG_ADDR);
    
        // set FIFO pointers to 0
        config[0] = MAX30101_REG_FIFO_WR; config[1] = 0x00;
        i2c_write(i2c_bus, config, 2, PPG_ADDR);
        config[0] = MAX30101_REG_FIFO_RD; config[1] = 0x00;
        i2c_write(i2c_bus, config, 2, PPG_ADDR);
}

int main(void)
{
        // power up delay for device
        k_msleep(1000);

        // init hr_context var
        hr_init(&hr_ctx);

        // check if I2C bus and sensor device are ready
        if (!device_is_ready(i2c_bus)){
                LOG_ERR("I2C bus not ready");
                return 0;
        } else {
                // scan for devices on I2C bus
                scan_i2c_bus(i2c_bus);
        }
        if (!device_is_ready(dev)){
                LOG_ERR("PPG sensor not ready");
                return 0;
        }

        // use helper function to configure device
        configure_sensor();
        LOG_INF("Sensor Active. Place finger firmly on sensor.");

        // ppg measurement loop
        while (1) {
                // read FIFO for data
                uint8_t ptrs[2] = {0};
                uint8_t reg_wr = MAX30101_REG_FIFO_WR;
                uint8_t reg_rd = MAX30101_REG_FIFO_RD;

                i2c_write_read(i2c_bus, PPG_ADDR, &reg_wr, 1, &ptrs[0], 1); 
                i2c_write_read(i2c_bus, PPG_ADDR, &reg_rd, 1, &ptrs[1], 1); 

                // calculate # of samples available
                int num_samples = ptrs[0] - ptrs[1];
                if (num_samples < 0) num_samples += 32;

                if (num_samples > 0) {
                        uint8_t fifo_data[6]; // 3 bytes for RED, 3 bytes for IR LED
                        uint8_t reg_data = MAX30101_REG_FIFO_DATA;
                        // read data from each sample
                        for (int i = 0; i < num_samples; i++) {
                                if (i2c_write_read(i2c_bus, PPG_ADDR, &reg_data, 1, fifo_data, 6) == 0) {
                                        // combine IR data into one val (bytes 3, 4, 5)
                                        uint32_t ir_val = ((uint32_t)fifo_data[3] << 16) | 
                                                        ((uint32_t)fifo_data[4] << 8)  | 
                                                        (uint32_t)fifo_data[5];
                                        ir_val &= 0x3FFFF; // mask to 18 bits
                                        // process data with hr algorithm
                                        hr_process(&hr_ctx, ir_val);

                                        if (hr_ctx.beat_detected) {
                                                LOG_INF("BPM: %d | HRV: %.2f ms", 
                                                        hr_ctx.current_bpm, (double)hr_ctx.current_rmssd);
                                        }
                                        
                                        // uncomment for raw data stream -> may be useful for plotting??
                                        /* LOG_INF("IR: %d", ir_val); */
                                }
                        }
                }
                // sleep for 40ms (~25Hz SR, processes ~16 samples per loop)
                k_msleep(40);
        }
        return 0;
}
