#ifndef HR_CALC_H
#define HR_CALC_H

#include <zephyr/kernel.h>
#include <math.h>

/* --- TUNING PARAMETERS --- */
/* Minimum time between beats. 300ms = Max 200 BPM. 
 * This filters out "double beats" caused by the dicrotic notch. */
#define MIN_BEAT_MS        300  

/* Samples for Moving Average (Smoothing) */
#define MA_SIZE            4    

typedef struct {
    float dc_filter_ir;
    float peak_threshold;
    int64_t last_beat_time;
    int32_t rr_buffer[10];
    uint8_t rr_index;
    int32_t current_bpm;
    float   current_rmssd;
    bool    beat_detected;
    
    /* Moving Average Buffer */
    uint32_t ma_buf[MA_SIZE];
    uint8_t ma_idx;
} hr_context_t;

static inline void hr_init(hr_context_t *ctx) {
    ctx->dc_filter_ir = 0;
    ctx->peak_threshold = 200.0f; /* Starting sensitivity */
    ctx->last_beat_time = 0;
    ctx->current_bpm = 0;
    for(int i=0; i<MA_SIZE; i++) ctx->ma_buf[i] = 0;
}

static inline void hr_process(hr_context_t *ctx, uint32_t ir_raw) {
    ctx->beat_detected = false;
    
    /* 1. Moving Average Filter (Smooths out high freq noise) */
    ctx->ma_buf[ctx->ma_idx] = ir_raw;
    ctx->ma_idx = (ctx->ma_idx + 1) % MA_SIZE;
    uint32_t smooth_ir = 0;
    for(int i=0; i<MA_SIZE; i++) smooth_ir += ctx->ma_buf[i];
    smooth_ir /= MA_SIZE;

    /* 2. DC Removal (High Pass Filter) */
    /* If first sample, initialize DC */
    if (ctx->dc_filter_ir == 0) ctx->dc_filter_ir = smooth_ir;
    
    /* Standard exponential filter */
    ctx->dc_filter_ir = 0.95f * ctx->dc_filter_ir + 0.05f * smooth_ir;
    
    /* 3. Extract AC Signal (Inverted) 
     * Blood absorbs IR, so a beat is a DIP in raw value.
     * We invert it so a beat becomes a POSITIVE peak.
     */
    float ac_signal = ctx->dc_filter_ir - smooth_ir;

    /* 4. Peak Detection Logic */
    int64_t now = k_uptime_get();
    
    /* Check if signal exceeds threshold AND enough time has passed */
    if (ac_signal > ctx->peak_threshold && 
       (now - ctx->last_beat_time) > MIN_BEAT_MS) {
        
        /* Valid Beat! */
        int32_t rr_interval = (int32_t)(now - ctx->last_beat_time);
        ctx->last_beat_time = now;
        ctx->beat_detected = true;

        /* Calculate BPM */
        ctx->current_bpm = 60000 / rr_interval;

        /* Dynamic Threshold Adjustment */
        /* Set threshold to 50% of this peak's height for next time */
        ctx->peak_threshold = ac_signal * 0.5f;
        if (ctx->peak_threshold < 100.0f) ctx->peak_threshold = 100.0f; /* Floor */

        /* HRV (RMSSD) Calculation */
        ctx->rr_buffer[ctx->rr_index++ % 10] = rr_interval;
        float sum_sq_diff = 0;
        int count = 0;
        for (int i = 0; i < 9; i++) {
            if (ctx->rr_buffer[i] > 0 && ctx->rr_buffer[i+1] > 0) {
                int32_t diff = ctx->rr_buffer[i+1] - ctx->rr_buffer[i];
                sum_sq_diff += (float)(diff * diff);
                count++;
            }
        }
        if (count > 0) ctx->current_rmssd = sqrtf(sum_sq_diff / count);
    }
    
    /* Decay threshold slowly if no beats found */
    ctx->peak_threshold *= 0.999f;
    if (ctx->peak_threshold < 50.0f) ctx->peak_threshold = 50.0f;
}

#endif