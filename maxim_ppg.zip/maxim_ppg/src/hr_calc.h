#ifndef HR_CALC_H
#define HR_CALC_H

#include <zephyr/kernel.h>
#include <math.h>

#define HR_FIFO_SIZE       32      /* MAX30102 FIFO Depth */
#define HR_WINDOW_SIZE     10      /* Number of beats to average for HRV */
#define MIN_BEAT_MS        300     /* 200 BPM max (refractory period) */
#define MAX_BEAT_MS        1500    /* 40 BPM min (reset if no beat) */

// define struct for HR measurement
typedef struct {
    // state variables
    float dc_filter_ir;
    float peak_threshold;
    
    // timing variables
    int64_t last_beat_time;
    
    // buffer for HRV measurement
    int32_t rr_buffer[HR_WINDOW_SIZE];
    uint8_t rr_index;
    
    // results variables
    int32_t current_bpm;
    float   current_rmssd;
    bool    beat_detected;
} hr_context_t;

// initialize HR calc algo
static inline void hr_init(hr_context_t *ctx) {
    ctx->dc_filter_ir = 0;
    ctx->peak_threshold = 50.0f; // starting threshold
    ctx->last_beat_time = 0;
    ctx->rr_index = 0;
    ctx->current_bpm = 0;
    ctx->current_rmssd = 0;
    ctx->beat_detected = false;
    // init buffer to 0
    for(int i=0; i<HR_WINDOW_SIZE; i++) ctx->rr_buffer[i] = 0;
}

// process single IR sample
static inline void hr_process(hr_context_t *ctx, uint32_t ir_raw) {
    ctx->beat_detected = false;
    int64_t now = k_uptime_get();

    /* 1. DC Removal (High Pass Filter) 
     * Removes the constant "DC" component (ambient light, finger static)
     * so we only see the "AC" component (heartbeat pulses).
     */
    float x = (float)ir_raw;
    ctx->dc_filter_ir = 0.95f * ctx->dc_filter_ir + 0.05f * x;
    float ac_signal = x - ctx->dc_filter_ir;

    /* Invert signal because pulses typically dip in raw IR */
    ac_signal = -ac_signal; 

    /* 2. Dynamic Threshold Update (Decay) */
    ctx->peak_threshold *= 0.99f;
    if (ctx->peak_threshold < 20.0f) ctx->peak_threshold = 20.0f;

    /* 3. Peak Detection */
    /* If signal > threshold AND enough time passed since last beat */
    if (ac_signal > ctx->peak_threshold && 
       (now - ctx->last_beat_time) > MIN_BEAT_MS) {
        
        /* 4. Valid Beat Found */
        int32_t rr_interval = (int32_t)(now - ctx->last_beat_time);
        ctx->last_beat_time = now;
        
        /* Update Threshold to avoid double-counting this peak */
        ctx->peak_threshold = ac_signal * 0.8f; 
        
        /* Calculate Instant BPM */
        ctx->current_bpm = 60000 / rr_interval;
        ctx->beat_detected = true;

        /* 5. HRV Calculation (RMSSD) */
        ctx->rr_buffer[ctx->rr_index++ % HR_WINDOW_SIZE] = rr_interval;

        /* Calculate RMSSD over buffer */
        float sum_sq_diff = 0;
        int count = 0;
        for (int i = 0; i < HR_WINDOW_SIZE - 1; i++) {
            int32_t diff = ctx->rr_buffer[i+1] - ctx->rr_buffer[i];
            /* Only count if buffer is filled with valid data */
            if (ctx->rr_buffer[i] > 0 && ctx->rr_buffer[i+1] > 0) {
                sum_sq_diff += (float)(diff * diff);
                count++;
            }
        }
        
        if (count > 0) {
            ctx->current_rmssd = sqrtf(sum_sq_diff / count);
        }
    }
}

#endif /* HR_CALC_H */