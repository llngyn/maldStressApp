#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/logging/log.h>

#include "hr_calc.h"

LOG_MODULE_REGISTER(PPG, LOG_LEVEL_INF);

const struct device *dev = DEVICE_DT_GET(DT_NODELABEL(max30101));

// define HR context struct
hr_context_t hr_ctx;

int main(void)
{
        // check if max30101 device is ready
        if (!device_is_ready(dev)) {
                LOG_ERR("PPG sensor device not ready");
                return -1;
        }
        LOG_INF("MAX30101 Device Ready");

        return 0;
}
