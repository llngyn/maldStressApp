#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/logging/log.h>
#include <zephyr/drivers/sensor/adxl345.h>
#include <math.h>

#define MOTION_THRESHOLD 1.0 

LOG_MODULE_REGISTER(Accelerometer, LOG_LEVEL_INF);

const struct device *dev = DEVICE_DT_GET(DT_NODELABEL(adxl345));

int main(void)
{
        // check if adxl345 device is ready
        if (!device_is_ready(dev)) {
                LOG_ERR("Accelerometer sensor device not ready");
                return -1;
        }
        LOG_INF("ADXL345 Device Ready");

        // configure device for +/- 2g range
        struct sensor_value range;
        sensor_value_from_double(&range, 2.0); // +/- 2g
        sensor_attr_set(dev, SENSOR_CHAN_ACCEL_XYZ, 
                        SENSOR_ATTR_FULL_SCALE, &range);

        // configure device for +/- 25 Hz sampling rate
        struct sensor_value odr;
        sensor_value_from_double(&odr, 25.0); // 25 Hz
        sensor_attr_set(dev, SENSOR_CHAN_ACCEL_XYZ, 
                        SENSOR_ATTR_SAMPLING_FREQUENCY, &odr);

        // variables for motion detection algorithm
        double prev_x = 0, prev_y = 0, prev_z = 0;
        bool first_sample = true;

        // read accel sensor data
        while(1) {
                struct sensor_value accel[3];
        
                // fetch x, y, z data
                if (sensor_sample_fetch(dev) == 0) {
                        sensor_channel_get(dev, SENSOR_CHAN_ACCEL_XYZ, accel);
                        
                        // fetch current x, y, z data readings
                        double curr_x = sensor_value_to_double(&accel[0]);
                        double curr_y = sensor_value_to_double(&accel[1]);
                        double curr_z = sensor_value_to_double(&accel[2]);

                        // check for motion
                        if (first_sample) {
                                prev_x = curr_x;
                                prev_y = curr_y;
                                prev_z = curr_z;
                                first_sample = false;
                        } else {
                                // calculate change from prev sample
                                double delta_x = curr_x - prev_x;
                                double delta_y = curr_y - prev_y;
                                double delta_z = curr_z - prev_z;

                                // update prev samples
                                prev_x = curr_x;
                                prev_y = curr_y;
                                prev_z = curr_z;

                                // calculate magnitude of change
                                double magnitude = sqrt(pow(delta_x, 2) + pow(delta_y, 2) + pow(delta_z, 2));

                                // check if motion exceeds threshold
                                if (magnitude > MOTION_THRESHOLD) {
                                        LOG_INF("Movement Detected with Magnitude: %.2f m/s^2", magnitude);
                                } else {
                                        // uncomment if want to see still w no movement detected
                                        /* LOG_INF("Still. Magnitude: %.2f", magnitude); */
                                }
                        }
                        // uncomment to print out full sensor data
                        // LOG_INF("Accel: X=%.2f, Y=%.2f, Z=%.2f",
                        //         sensor_value_to_double(&accel[0]),
                        //         sensor_value_to_double(&accel[1]),
                        //         sensor_value_to_double(&accel[2]));
                } else {
                        LOG_ERR("Failed to fetch accel data");
                }

                k_sleep(K_MSEC(40)); // sleep for 40 ms (25 Hz sampling rate)
        }

        return 0;
}
