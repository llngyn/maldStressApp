#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/logging/log.h>
#include <zephyr/drivers/spi.h>
#include <math.h>
#include <stdio.h>

#include <zephyr/drivers/sensor/adxl345.h>
#include <zephyr/drivers/sensor/veml7700.h>

#define MOTION_THRESHOLD 1.0 

LOG_MODULE_REGISTER(SensorHub, LOG_LEVEL_INF);

// get device labels
const struct device *acc_dev = DEVICE_DT_GET(DT_NODELABEL(adxl345));
const struct device *light_dev = DEVICE_DT_GET(DT_NODELABEL(veml7700));

// init EDA sensor SPI device label (looks a little diff)
const struct spi_dt_spec eda_dev = SPI_DT_SPEC_GET(DT_NODELABEL(mcp3201), SPI_OP_MODE_MASTER | SPI_WORD_SET(8), 0);

int main(void)
{
        // check if adxl345 device is ready
        if (!device_is_ready(acc_dev)) {
                LOG_ERR("Accelerometer sensor device not ready");
                return -1;
        }
        LOG_INF("ADXL345 Device Ready");

        // check if veml7700 device is ready
        if (!device_is_ready(light_dev)) {
                LOG_ERR("Light sensor device not ready");
                return -1;
        }
        LOG_INF("VEML7700 Device Ready");

        // check if SPI Bus/EDA sensor device is ready
        if (!spi_is_ready_dt(&eda_dev)) {
                LOG_ERR("SPI bus not ready.");
                return 0;
        }
        LOG_INF("SPI Bus Ready. Reading GSR Sensor...");

        // ADXL345 CONFIGURATION
        // configure device for +/- 2g range
        struct sensor_value range;
        sensor_value_from_double(&range, 2.0); // +/- 2g
        sensor_attr_set(acc_dev, SENSOR_CHAN_ACCEL_XYZ, 
                        SENSOR_ATTR_FULL_SCALE, &range);
        // configure device for +/- 25 Hz sampling rate
        struct sensor_value odr;
        sensor_value_from_double(&odr, 25.0); // 25 Hz
        sensor_attr_set(acc_dev, SENSOR_CHAN_ACCEL_XYZ, 
                        SENSOR_ATTR_SAMPLING_FREQUENCY, &odr);
        // init variables for motion detection algorithm
        double prev_x = 0, prev_y = 0, prev_z = 0;
        bool first_sample = true;

        // VEML7700 CONFIGURATION
        // set gain value to 1/8 gain
        struct sensor_value gain_val;
        gain_val.val1 = VEML7700_ALS_GAIN_1_8;
        gain_val.val2 = 0; // fraction to 0
        int ret = sensor_attr_set(light_dev, SENSOR_CHAN_LIGHT, 
                                (enum sensor_attribute)SENSOR_ATTR_VEML7700_GAIN,
                                &gain_val);
        if (ret != 0) {
                LOG_ERR("Failed to set gain");
                return -1;
        }
        // set integration time to 100ms
        struct sensor_value it_val;
        it_val.val1 = VEML7700_ALS_IT_100;
        it_val.val2 = 0;
        ret = sensor_attr_set(light_dev, SENSOR_CHAN_LIGHT, 
                        (enum sensor_attribute)SENSOR_ATTR_VEML7700_ITIME, 
                        &it_val);
        if (ret != 0) {
                LOG_ERR("Failed to set integration time");
                return -1;
        }

        int loop = 1; // keep track of cycles to sample devices at dedicated samp freq

        // read sensor data in main loop
        while(1) {
                // init structs for sensor data
                struct sensor_value accel[3];   // accelerometer data
                struct sensor_value lux;        // ambient light sensor data

                // init buffer for eda data
                uint8_t eda_rx_buffer[2] = {0, 0};
                // config spi buffer and definitions
                const struct spi_buf rx_buf = {
                        .buf = eda_rx_buffer,
                        .len = sizeof(eda_rx_buffer)
                };
                const struct spi_buf_set rx_set = {
                        .buffers = &rx_buf,
                        .count = 1
                };
        
                // Motion Detection
                // fetch x, y, z data from accelerometer
                if (sensor_sample_fetch(acc_dev) == 0) {
                        sensor_channel_get(acc_dev, SENSOR_CHAN_ACCEL_XYZ, accel);
                        
                        // fetch current x, y, z data readings
                        double curr_x = sensor_value_to_double(&accel[0]);
                        double curr_y = sensor_value_to_double(&accel[1]);
                        double curr_z = sensor_value_to_double(&accel[2]);

                        // check for motion
                        if (first_sample) {
                                prev_x = curr_x;
                                prev_y = curr_y;
                                prev_z = curr_z;
                                first_sample = false;
                        } else {
                                // calculate change from prev sample
                                double delta_x = curr_x - prev_x;
                                double delta_y = curr_y - prev_y;
                                double delta_z = curr_z - prev_z;

                                // update prev samples
                                prev_x = curr_x;
                                prev_y = curr_y;
                                prev_z = curr_z;

                                // calculate magnitude of change
                                double magnitude = sqrt(pow(delta_x, 2) + pow(delta_y, 2) + pow(delta_z, 2));

                                // check if motion exceeds threshold
                                if (magnitude > MOTION_THRESHOLD) {
                                        LOG_INF("Movement Detected with Magnitude: %.2f m/s^2", magnitude);
                                } else {
                                        // uncomment if want to see still w no movement detected
                                        /* LOG_INF("Still. Magnitude: %.2f", magnitude); */
                                }
                        }
                        // uncomment to print out full sensor data
                        // LOG_INF("Accel: X=%.2f, Y=%.2f, Z=%.2f",
                        //         sensor_value_to_double(&accel[0]),
                        //         sensor_value_to_double(&accel[1]),
                        //         sensor_value_to_double(&accel[2]));
                } else {
                        LOG_ERR("Failed to fetch accel data");
                }

                // INDOOR/OUTDOOR DETECTION
                if (loop==25){ // sampling at 1 Hz (25 Hz/25=1Hz)
                        // fetch sample from veml7700 device
                        if (sensor_sample_fetch(light_dev) < 0) {
                                LOG_ERR("VEML7700 sample fetch failed");
                                continue;
                        }
                        // read the light channel
                        if (sensor_channel_get(light_dev, SENSOR_CHAN_LIGHT, &lux) < 0) {
                                LOG_ERR("Cannot read veml7700 light channel");
                                continue;
                        }
                        // // uncomment to print full light sensor data
                        // LOG_INF("Ambient Light: %d.%06d Lux", lux.val1, lux.val2);

                        // differentiate between indoor vs. outdoor
                        // > 2000 lux == outdoor
                        // < 500 lux == indoor
                        if (lux.val1 > 2000) {
                                LOG_INF("Status: Outdoors");
                        } else {
                                LOG_INF("Status: Indoors");
                        }
                        loop = 0;
                }

                // MEASURE EDA DATA
                // since MCP3201 doesn't need a command byte, we just read 2 bytes
                int err = spi_read_dt(&eda_dev, &rx_set);
                
                if (err) {
                        LOG_ERR("SPI Read Failed (Err: %d)", err);
                } else {
                        /* decode MCP3201 data (12-bit)
                        * The MCP3201 returns 2 bytes.
                        * Byte 0: [0 0 0 Null B11 B10 B9 B8]
                        * Byte 1: [B7 B6 B5 B4 B3 B2 B1 B0]
                        * * Logic: 
                        * 1. Mask Byte 0 to remove top 3 bits + Null bit (0x1F)
                        * 2. Shift Byte 0 left by 7 (or 8 depending on exact timing alignment)
                        */
                        
                        // combine to 16-bit integer for easier processing
                        uint16_t raw_val = ((uint16_t)eda_rx_buffer[0] << 8) | eda_rx_buffer[1];
                        
                        // actually format raw data to print:
                        /* MCP3201 formatting often requires shifting right by 1 bit 
                        * to remove trailing zeros depending on clock edge. 
                        * Standard formula: (Buffer[0] & 0x1F) << 7 | (Buffer[1] >> 1)
                        */
                        uint16_t adc_result = ((eda_rx_buffer[0] & 0x1F) << 7) | (eda_rx_buffer[1] >> 1);

                        /* Print Raw Data */
                        LOG_INF("GSR Raw: %d (V: %.2f)", adc_result, (double)(adc_result * 3.3 / 4096.0));
                }


                loop++; // increment # of cycles
                k_sleep(K_MSEC(40)); // sleep for 40 ms (25 Hz sampling rate)
        }

        return 0;
}
