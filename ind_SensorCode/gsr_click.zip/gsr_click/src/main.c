#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/logging/log.h>
#include <zephyr/drivers/spi.h>
#include <stdio.h>

LOG_MODULE_REGISTER(GSR_Test, LOG_LEVEL_INF);

// init EDA sensor SPI device
const struct spi_dt_spec adc_dev = SPI_DT_SPEC_GET(DT_NODELABEL(mcp3201), SPI_OP_MODE_MASTER | SPI_WORD_SET(8), 0);

int main(void)
{
        k_msleep(1000);

        // check if SPI Bus/EDA sensor device is ready
        if (!spi_is_ready_dt(&adc_dev)) {
                LOG_ERR("SPI bus not ready.");
                return 0;
        }
        LOG_INF("SPI Bus Ready. Reading GSR Sensor...");

        while (1) {
                // init buffer for data
                uint8_t rx_buffer[2] = {0, 0};
                
                // config spi buffer and definitions
                const struct spi_buf rx_buf = {
                        .buf = rx_buffer,
                        .len = sizeof(rx_buffer)
                };
                const struct spi_buf_set rx_set = {
                        .buffers = &rx_buf,
                        .count = 1
                };

                // read device data
                // since MCP3201 doesn't need a command byte, we just read 2 bytes
                int err = spi_read_dt(&adc_dev, &rx_set);
                
                if (err) {
                        LOG_ERR("SPI Read Failed (Err: %d)", err);
                } else {
                        /* decode MCP3201 data (12-bit)
                        * The MCP3201 returns 2 bytes.
                        * Byte 0: [0 0 0 Null B11 B10 B9 B8]
                        * Byte 1: [B7 B6 B5 B4 B3 B2 B1 B0]
                        * * Logic: 
                        * 1. Mask Byte 0 to remove top 3 bits + Null bit (0x1F)
                        * 2. Shift Byte 0 left by 7 (or 8 depending on exact timing alignment)
                        */
                        
                        // combine to 16-bit integer for easier processing
                        uint16_t raw_val = ((uint16_t)rx_buffer[0] << 8) | rx_buffer[1];
                        
                        // actually format raw data to print:
                        /* MCP3201 formatting often requires shifting right by 1 bit 
                        * to remove trailing zeros depending on clock edge. 
                        * Standard formula: (Buffer[0] & 0x1F) << 7 | (Buffer[1] >> 1)
                        */
                        uint16_t adc_result = ((rx_buffer[0] & 0x1F) << 7) | (rx_buffer[1] >> 1);

                        /* Print Raw Data */
                        LOG_INF("GSR Raw: %d (V: %.2f)", adc_result, (double)(adc_result * 3.3 / 4096.0));
                }

                k_msleep(100); /* 10Hz Sampling */
        }
        return 0;
}
