#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/logging/log.h>
#include <zephyr/drivers/sensor/veml7700.h>

LOG_MODULE_REGISTER(LightSensor, LOG_LEVEL_INF);

const struct device *dev = DEVICE_DT_GET(DT_NODELABEL(veml7700));

int main(void)
{
        // check if veml7700 device is ready
        if (!device_is_ready(dev)) {
                LOG_ERR("Light sensor device not ready");
                return -1;
        }
        LOG_INF("VEML7700 Device Ready");

        // set gain value to 1/8 gain
        struct sensor_value gain_val;
        gain_val.val1 = VEML7700_ALS_GAIN_1_8;
        gain_val.val2 = 0; // fraction to 0
        int ret = sensor_attr_set(dev, SENSOR_CHAN_LIGHT, 
                                (enum sensor_attribute)SENSOR_ATTR_VEML7700_GAIN,
                                &gain_val);
        if (ret != 0) {
                LOG_ERR("Failed to set gain");
                return -1;
        }
        // set integration time to 100ms
        struct sensor_value it_val;
        it_val.val1 = VEML7700_ALS_IT_100;
        it_val.val2 = 0;
        ret = sensor_attr_set(dev, SENSOR_CHAN_LIGHT, 
                        (enum sensor_attribute)SENSOR_ATTR_VEML7700_ITIME, 
                        &it_val);
        if (ret != 0) {
                LOG_ERR("Failed to set integration time");
                return -1;
        }

        while (1) {
                struct sensor_value lux;

                // fetch sample from device
                if (sensor_sample_fetch(dev) < 0) {
                        LOG_ERR("Sensor sample fetch failed");
                        continue;
                }

                // read the light channel
                if (sensor_channel_get(dev, SENSOR_CHAN_LIGHT, &lux) < 0) {
                        LOG_ERR("Cannot read light channel");
                        continue;
                }

                // print result
                LOG_INF("Ambient Light: %d.%06d Lux", lux.val1, lux.val2);

                // differentiate between indoor vs. outdoor
                // > 2000 lux == outdoor
                // < 500 lux == indoor
                if (lux.val1 > 2000) {
                        LOG_INF("Status: Outdoors");
                } else {
                        LOG_INF("Status: Indoors");
                }

                k_sleep(K_MSEC(1000)); // sleep for 1 sec (1 Hz sampling rate)
        }

        return 0;
}
